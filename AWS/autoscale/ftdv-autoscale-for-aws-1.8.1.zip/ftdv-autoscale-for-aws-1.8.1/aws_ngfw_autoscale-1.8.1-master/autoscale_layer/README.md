This zip file needs to be deployed as Lambda layer, 
Generated Lambda layer URL has to be shared with Autoscale Manager. 

Link:
https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html

Below link may get brocken as its a forum: But good example with GUI
https://medium.com/@adhorn/getting-started-with-aws-lambda-layers-for-python-6e10b1f9a5d


